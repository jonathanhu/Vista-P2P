create or replace public synonym XXSV_PO_REPORT_UTL for bolinf.XXSV_PO_REPORT_UTL;
create or replace public synonym XXSV_P2P_V for bolinf.XXSV_P2P_V;
/
exit
/