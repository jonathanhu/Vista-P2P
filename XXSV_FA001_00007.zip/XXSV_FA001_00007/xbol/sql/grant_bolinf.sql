grant all on XXSV_PO_REPORT_UTL to apps with grant option;
grant all on XXSV_P2P_V to apps;
grant select on XXSV_P2P_V to SV_DWUSER;grant all on GL_CODE_COMBINATIONS_KFV to apps with grant option;
grant all on FA_BOOKS_V to apps with grant option; 
/
exit
/